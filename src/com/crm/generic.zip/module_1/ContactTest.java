package com.crm.module_1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.crm.generic.BaseClass;

public class ContactTest extends BaseClass
{
	
	@Test
	public void testContact()
	{
		System.out.println("execute contact test -----1 ");
	}
	@Test
	public void testModifyContact()
	{
		System.out.println("modify contact test -------2");
	}
	
}
